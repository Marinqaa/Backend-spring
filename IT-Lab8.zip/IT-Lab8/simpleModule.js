let url = 'http://api.ti.wieik.pk.edu.pl/log';

function log(message) {
    console.log("message: ", message);
}

module.exports.log = log;
module.exports.endPoint = url;

const simpleModule = require('./simpleModule');
console.log(simpleModule);

simpleModule.log("message");
console.log(simpleModule.endPoint);