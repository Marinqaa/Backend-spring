class ClassModule{
    log(message, id, data){
        console.log("Logger Class, message: " + message + " id: " + id);
    }
}
module.exports = ClassModule;