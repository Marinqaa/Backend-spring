const EventEmitter = require('events');

class Logger extends EventEmitter {
    log(message, id, data) {
        console.log('Logger, message: ${message}, id: ${id}, data: ${data}');

        this.emit('messageLogger', {id: id, data: data});
    }
}

module.exports = Logger;
