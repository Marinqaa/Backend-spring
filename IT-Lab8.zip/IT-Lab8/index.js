// console.log("Hello World");

function hello(name) {
    console.log("Hello " + name + "!");
}
const hi = function(name) {
    console.log("Hi " + name + "!");
}

hello("Damian");
hi("Marina");

setTimeout(function (){
    hello("123");
}, 5000);

const url = require('url');

const path = require('path');
const os = require('os');
let filePath = path.parse(__filename);
console.log(filePath);

let totalMemory = os.totalmem();
let freeMemory = os.freemem();
console.log('Total memory: ' + totalMemory);
console.log(`Free memory: ${freeMemory}`);

const fs = require('fs');
const allFiles = fs.readdirSync('./');
console.log(allFiles);

fs.readdir(__dirname, function (err, files) {
    if (err) console.log('Error: ', err);
    else console.log('Result: ', files);
});

const ClassModule = require('./classModule');

const classModule = new ClassModule();
classModule.log("content for a module in the class", 1, {data: 123});

const EventEmitter = require('events');
const emitter = new EventEmitter();

emitter.on('message', function (){
    console.log('Listener invoked');
});

emitter.on('messageArg', (arg) => {
    console.log('Listener invoked with argument ', arg);
});

emitter.emit('message');
emitter.emit('messageArg', 'abc');
emitter.emit('message', { id: 1, url: 'https://abc.pl' });

const Logger = require('./logger');
const logger = new Logger();

logger.on('messageLogger', (arg) => {
    console.log('Listener Logger invoked: ', arg);
})
logger.log('Message for logger', 2, 'abc');

// Function to read a file and send it in the response
function readFileAndRespond(filePath, contentType, res) {
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.statusCode = 404;
            res.end('Not Found');
            return;
        }
        res.setHeader('Content-type', contentType);
        res.write(data);
        res.end();
    });
}

// Function to read a file synchronously
function readFileSync(filePath) {
    return fs.readFileSync(filePath, 'utf-8');
}

//server creation
const http = require('http');

//SERVER1
const server1 = http.createServer();
server1.on('connection', (socket) => {
    console.log('New connection...');
});
server1.on('request', (req, res) => {
    res.setHeader('Content-type', 'text/html; charset=utf-8');
    res.write('Hello World!<br/>');
    res.end(`Hello ${new Date()}`);
    console.log('New request');
});
server1.listen(3001);
console.log('server1 is waiting on port 3001...');

let largeFile = fs.createWriteStream('./large.file');
for (let i=0; i<=1e5; i++) {
    largeFile.write('Lorem ipsum dolor sit amet, consectetur adipiscing elit. ' +
        'Vestibulum ut egestas odio. Curabitur tincidunt, dolor ut venenatis dictum, ' +
        'sapien sapien fermentum arcu, a finibus nisl mauris vel leo. Quisque ex nibh, ' +
        'consectetur ac nibh nec, rhoncus maximus orci. Ut sed dolor vulputate, scelerisque ' +
        'odio id, tincidunt nisl. Praesent luctus tortor ut lorem faucibus tristique. Maecenas ' +
        'dapibus mattis orci. Vivamus finibus consectetur egestas. Etiam non urna ligula. Etiam ' +
        'scelerisque dui nec justo posuere, nec feugiat est pharetra. Proin luctus turpis eros. ' +
        'Integer mi elit, porta dapibus urna sed, elementum sollicitudin dolor. Sed consectetur ' +
        'tempor nulla, nec tincidunt massa. Integer molestie auctor nisl vel ultrices. Ut tincidunt, ' +
        'neque et lacinia placerat, turpis sem laoreet ipsum, in sollicitudin urna arcu id nibh. ' +
        'Praesent fringilla leo ante, a luctus massa euismod in. Maecenas sit amet tincidunt magna. ' +
        'Nulla vulputate, lectus quis accumsan congue, justo diam pretium massa, eget facilisis ante ' +
        'nulla lobortis ligula. Nulla facilisi.\n');
}
largeFile.end();

//SERVER2
const server2 = http.createServer();
server2.on('request', (req, res) => {
    fs.readFile('./large.file', (err, data) => {
        if (err) throw err;
        res.setHeader('Content-type', 'text/plain; charset=utf-8');
        res.write(data);
        res.end();
    });
    console.log('New request on port 3002');
});

server2.listen(3002);
console.log('server2 is waiting on port 3002...');

server2.on('request', (req, res) => {
    const source = fs.createReadStream('./large.file');
    res.setHeader('Content-type', 'text/plain; charset=utf-8');
    source.pipe(res);
    console.log('New request on port 3002');
});


//SERVER3
const server3 = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const page = parsedUrl.query.page;

    if(req.url === '/' || page){
        const header = fs.readFileSync(path.join(__dirname, 'header.html'), 'utf-8');
        const menu = fs.readFileSync(path.join(__dirname, 'menu.html'), 'utf-8');
        const footer = fs.readFileSync(path.join(__dirname, 'footer.html'), 'utf-8');
        const content = page ? readFileSync(path.join(__dirname, `${page}.html`)) : readFileSync(path.join(__dirname, 'main.html'));
        const index = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf-8');
        const pageContent = index.replace('[[HEADER]]', header)
                                .replace('[[MENU]]', menu)
                                .replace('[[FOOTER]]', footer)
                                .replace('[[CONTENT]]', content);

        res.setHeader('Content-type', 'text/html; charset=utf-8');
        res.write(pageContent);
        res.end();
    } else if (req.url === '/api/numbers') {
        res.setHeader('Content-type', 'application/json; charset=utf-8');
        res.write(JSON.stringify([1, 2, 3]));
        res.end();
    } else if (req.url === '/styl.css') {
        readFileAndRespond(path.join(__dirname, 'styl.css'), 'text/css; charset=utf-8', res);
    } else if (req.url === '/script.js') {
        readFileAndRespond(path.join(__dirname, 'script.js'), 'application/javascript; charset=utf-8', res);
    } else if (req.url === '/quadratic.js') {
        readFileAndRespond(path.join(__dirname, 'quadratic.js'), 'application/javascript; charset=utf-8', res);
    } else {
        res.statusCode = 404;
        res.setHeader('Content-type', 'text/plain; charset=utf-8');
        res.write('404 Not Found');
        res.end();
    }
});

server3.listen(3003);
console.log('server3 is waiting on port 3003...');
