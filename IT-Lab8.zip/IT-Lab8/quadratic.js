class Quadratic {
    #A;
    #B;
    #C;
    #delta;
    #x1;
    #x2;

    constructor(a, b, c) {
        this.#A = a;
        this.#B = b;
        this.#C = c;
        this.#delta = null;
        this.#x1 = null;
        this.#x2 = null;
    }

    calcDelta() {
        this.#delta = (this.#B * this.#B) - 4 * this.#A * this.#C;
        return this.#delta;
    }

    zeroPlaces() {
        let d = this.calcDelta();
        if (d > 0) {
            this.#x1 = ((-this.#B) - Math.sqrt(d)) / (2 * this.#A);
            this.#x2 = ((-this.#B) + Math.sqrt(d)) / (2 * this.#A);
        } else if (d === 0) {
            this.#x1 = (-this.#B) / (2 * this.#A);
        } else {
            this.#x1 = null;
            this.#x2 = null;
        }
    }

    getX1() {
        return this.#x1;
    }

    getX2() {
        return this.#x2;
    }

    getDelta() {
        return this.#delta;
    }

    validate() {
        if (isNaN(this.#A) || isNaN(this.#B) || isNaN(this.#C)) {
            return false;
        }
        return true;
    }

    calculate() {
        if (this.validate()) {
            this.zeroPlaces();
        } else {
            console.error('Invalid data provided');
        }
    }
}

function hook() {
    let element = document.getElementById('calculate');
    element.addEventListener('click', function (event) {
        event.preventDefault();  // Prevent form submission
        let a = parseFloat(document.getElementById('coeff_a').value);
        let b = parseFloat(document.getElementById('coeff_b').value);
        let c = parseFloat(document.getElementById('coeff_c').value);

        let equation = new Quadratic(a, b, c);
        equation.calculate();

        let list = document.getElementById('list');
        list.innerHTML = '';  // Clear previous results

        let result = document.createTextNode('Result');
        let ul = document.createElement('ul');
        list.appendChild(result);
        list.appendChild(ul);

        if (equation.getDelta() === null) {
            ul.appendChild(createListItem('Invalid data provided'));
            return false;
        }

        if (equation.getDelta() > 0) {
            ul.appendChild(createListItem('x₁ = ' + equation.getX1()));
            ul.appendChild(createListItem('x₂ = ' + equation.getX2()));
        } else if (equation.getDelta() === 0) {
            ul.appendChild(createListItem('x = ' + equation.getX1()));
        } else {
            ul.appendChild(createListItem('No zero places, Δ < 0'));
        }
    });
}

function createListItem(text) {
    let li = document.createElement('li');
    li.appendChild(document.createTextNode(text));
    return li;
}

document.addEventListener('DOMContentLoaded', hook);
