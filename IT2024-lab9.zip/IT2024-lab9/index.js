
const express = require('express');
const app = express();
const Joi = require('joi');
const path = require("path");
//const ejs = require('ejs');

app.use(express.json());
let list = [
    { id: 1, name: 'ALFA ROMEO'} ,
    { id: 2, name: 'AUDI'} ,
    { id: 3, name: 'BMW' } ,
    { id: 4, name: 'CHRYSLER' },
    { id: 5, name: 'CITROEN' },
    { id: 6, name: 'DAIHATSU' },
    { id: 7, name: 'FIAT' },
    { id: 8, name: 'FORD' },
    { id: 9, name: 'HONDA' },
    { id: 10, name: 'ISUZU' },
    { id: 11, name: 'JAGUAR' },
    { id: 12, name: 'LADA' },
    { id: 13, name: 'LANCIA' },
    { id: 14, name: 'MAZDA' },
    { id: 15, name: 'MERCEDES' },
    { id: 16, name: 'MITSUBISHI' },
    { id: 17, name: 'NISSAN' },
    { id: 18, name: 'OPEL' },
    { id: 19, name: 'PEUGEOT' },
    { id: 20, name: 'PORSCHE' },
    { id: 21, name: 'RENAULT' },
    { id: 22, name: 'ROVER' },
    { id: 23, name: 'SAAB' },
    { id: 24, name: 'SEAT' },
    { id: 25, name: 'SKODA' },
    { id: 26, name: 'SUBARU' },
    { id: 27, name: 'SUZUKI' },
    { id: 28, name: 'TOYOTA' },
    { id: 29, name: 'VOLVO' },
    { id: 30, name: 'VW' }
];

app.get('/api/list', (req, res) => {
    res.send(list);
});
app.get('/api/list/:id', (req, res) => {
    let element = list.find(l => l.id === parseInt(req.params.id));
    if (!element) res.status(404).send('Item with this ID was not found');
    else res.send(element);
});

/*
app.post('/api/list', (req, res) => {
    if(!req.body.name || req.body.name.length < 3) {
        res.status(400).send('The name is required and must be min. 3 characters.');
        return;
    }
    const element = {
        id: list.length + 1,
        name: req.body.name
    };
    list.push(element);
    res.send(element);
});
*/

app.post('/api/list', (req, res) => {
    const schema = Joi.object().keys({
        name: Joi.string().min(3).required(),
        year: Joi.number().integer().min(1900).max(new Date().getFullYear())
    });
    const result = schema.validate(req.body);
    console.log(result);

    if(result.error) {
        res.status(400).send(result.error.details[0].message);
        return;
    }
    const { name, year } = req.body;
    const element = {
        id: list.length + 1,
        name: name,
        year: req.body.year
    };

    list.push(element);
    res.send(element);
});
app.put('/api/list/:id', (req, res) => {
    let element = list.find(l => l.id === parseInt(req.params.id));
    if (!element) res.status(404).send('Item with this ID was not found');

    const result = checkElement(req.body);
    if (result.error) {
        res.status(400).send(result.error.details[0].message);
        return;
    }
    /*if ('year' in req.body) {
        element.year = req.body.year;
    }*/

    element.name = req.body.name;
    element.year = req.body.year;
    res.send(element);
});

function checkElement(element) {
    const schema = Joi.object().keys({
        name: Joi.string().min(3).required(),
        year: Joi.number().integer().min(1900).max(new Date().getFullYear())
    });
    return schema.validate(element);
}
app.delete('/api/list/:id', (req, res) => {
    let element = list.find(l => l.id === parseInt(req.params.id));// parameter is a String
    if (!element)
        return res.status(404).send('Item with this ID was not found');
    let index = list.indexOf(element);
    list.splice(index, 1);
    res.send(element);
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname,'views'));

app.get('/', (req, res) => {
    res.render('index', { user: 'test' }); // Ensure 'user' variable is passed here
});

app.use(express.static(path.join(__dirname, 'static')));

app.get('/list', (req, res) => {
    res.render('list', { list: list });
});

app.get('/list/:id(\\d+)', (req, res) => {
    let element = list.find(l => l.id === parseInt(req.params.id));
    if (!element) res.status(404).send('Item with this ID was not found');
    else res.send(element);
});

app.use((req,res,next) => {
    res.render('404.ejs', { url : req.url });
});


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Waiting on port ${port}...`));

