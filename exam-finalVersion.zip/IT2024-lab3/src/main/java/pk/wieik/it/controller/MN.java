package pk.wieik.it.controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import pk.wieik.it.model.MNuser;
import pk.wieik.it.model.Tools;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "MN", value = "/MN")
public class MN extends HttpServlet {
    public HashMap<String, MNuser> users;

    @Override
    public void init() throws ServletException {
        this.users = new HashMap<>();
        users.put("user1", new MNuser("user1", "user1", 1));
        users.put("user2", new MNuser("user2", "user2", 1));
        users.put("user3", new MNuser("user3", "user3", 2));
        users.put("admin", new MNuser("admin", "admin", 2));
        getServletContext().setAttribute("users", users);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        ServletContext context = getServletContext();
        PrintWriter out = response.getWriter();
        String page = request.getParameter("page");
        page = Tools.parsePage(page, "main;quadratic;third;settings");

        HttpSession session = request.getSession();
        String attribute1 = (String) session.getAttribute("attribute1");
        Integer attribute2 = (Integer) session.getAttribute("attribute2");
        if (attribute1 == null)
            attribute1 = "";
        if (attribute2 == null)
            attribute2 = 0;

        MNuser user = (MNuser) session.getAttribute("user");
        if (user == null) {
            user = new MNuser();
            session.setAttribute("user", user);
        }


        String template = Tools.getTemplate("index.html", context);

        template = Tools.fill(template, "HEADER", "header.html", context);
        //template = Tools.fill(template, "MENU", "menu.html", context);


        if (user.getPrivileges() > 0)
            page = Tools.parsePage(page, "main;quadratic;third;settings");
        if (user.getPrivileges() > 1)
            page = Tools.parsePage(page, "main;quadratic;third;settings");


        template = Tools.fill(template, "CONTENT", page + ".html", context);
        template = Tools.fill(template, "FOOTER", "footer.html", context);

        String loggedInMessage;
        if (user.getPrivileges() > 0) {
            MNuser storedUser = users.get(user.getLogin());
            if (storedUser != null) {
                loggedInMessage = "You are logged in as <b>" + storedUser.getLogin() + "</b>";
            } else {
                loggedInMessage = "";
            }

//            if (user.getPrivileges() == 1) {
//                loggedInMessage = "You are logged in as <b>user</b>";
//            } else if (user.getPrivileges() == 2) {
//                loggedInMessage = "You are logged in as <b>admin</b>";
//            } else {
//                loggedInMessage = "";
//            }

            template = Tools.fill(template, "MENU", "menu2.html", context);
            template = template.replace("[[LOGIN]]", loggedInMessage);
        } else {
            template = Tools.fill(template, "MENU", "menu.html", context);
        }


        String[] jsFiles = {"script.js", "quadratic.js"};

        template = Tools.addScript(template, jsFiles);

        /*int value = 0;
        Cookie[] cookies = request.getCookies();
        Cookie counterCookie = new Cookie("counter", "0");
        for (Cookie ciastko : cookies) {
            if (ciastko.getName().equals("counter"))
                counterCookie = ciastko;
        }
        try {
            value = Integer.parseInt(counterCookie.getValue(), 0);
        } catch (NumberFormatException e) {
            value = 0;
        }
        value++;
        Cookie licznik = new Cookie("counter", Integer.toString(value));
        licznik.setMaxAge(60 * 60 * 24);
        response.addCookie(licznik);*/
        /*out.println("counter: " + value);*/


//        String page2 = request.getParameter("page");

//        else

        out.println(template);
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null)
            action = "";

        HttpSession session = request.getSession();
        MNuser user = (MNuser) session.getAttribute("user");

        ServletContext application = getServletContext();

        if (user == null) {
            user = new MNuser();
            session.setAttribute("user", user);
        }

        if (action.equals("login")) {
            String login = request.getParameter("login");
            String password = request.getParameter("password");

            if ("user".equals(login) && "user".equals(password)) {
                user.setLogin(login);
                user.setPrivileges(1);
                session.setAttribute("user", user);


            } else if ("admin".equals(login) && "admin".equals(password)) {
                user.setLogin(login);
                user.setPrivileges(2);
                session.setAttribute("user", user);
            }
            user.setBackgroundColor(user.getBackgroundColor());
            //response.sendRedirect("index.jsp");

            for (Map.Entry<String, MNuser> entry : users.entrySet()) {
                MNuser storedUser = entry.getValue();
                if (storedUser.getLogin().equals(login) && storedUser.getPassword().equals(password)) {
                    // Set the user in the session and redirect to the appropriate page
                    session.setAttribute("user", storedUser);

                    if (storedUser.getPrivileges() == 1) {
                        response.sendRedirect("index.jsp");
                    } else if (storedUser.getPrivileges() == 2) {
                        response.sendRedirect("index.jsp");
                    }
                    return;
                }
            }
        } else if (action.equals("settings")) {
            if (user.getPrivileges() > 0) {
                String name = request.getParameter("name");
                String surname = request.getParameter("surname");
                String ageString = request.getParameter("age");
                //user.setBackgroundColor(backgroundColor);
                String backgroundColor = request.getParameter("backgroundColor");
                if (backgroundColor == null) backgroundColor = "";
                application.setAttribute("backgroundColor", backgroundColor);
                user.setBackgroundColor(backgroundColor);

                if (name != null && surname != null && ageString != null && !name.isEmpty() && !surname.isEmpty() && !ageString.isEmpty())  {
                    int age = Integer.parseInt(ageString);
                    user.setName(name);
                    user.setSurname(surname);
                    user.setAge(age);
                    //user.setBackgroundColor(backgroundColor);
                    session.setAttribute("message", "Settings has been saved.<br>Click <a href=\"index.jsp\">here</a> to return to the main page");
                } else {
                    session.setAttribute("message", ""); // Clear the message if inputs are null
                }
            } else {
                response.sendRedirect("index.jsp");
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp?page=settings");
            dispatcher.forward(request, response);
        } else if (action.equals("administration")) {
            String backgroundColor = request.getParameter("backgroundColor");
            if (backgroundColor == null) backgroundColor = "";
            application.setAttribute("backgroundColor", backgroundColor);

            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp?page=administration");
            dispatcher.forward(request, response);
        } else if (action.equals("changePermissions")) {
            if (user.getPrivileges() == 2) { // Check if the user is an administrator
                String login = request.getParameter("login");
                int permissions = Integer.parseInt(request.getParameter("permissions"));

                // Update user permissions
                MNuser targetUser = users.get(login);
                if (targetUser != null) {
                    targetUser.setPrivileges(permissions);
                }

                // Redirect back to administration page
                response.sendRedirect("MN?action=administration");
                return;
            } else {
                // Non-admin users are not allowed to change permissions
                response.sendRedirect("MN?action=administration");
                return;
            }

        } else if (action.equals("registration")){
            String loginRegistration= request.getParameter("loginRegistration");
            String passwordRegistration= request.getParameter("passwordRegistration");
            System.out.println(loginRegistration);
            System.out.println(passwordRegistration);

            if (loginRegistration != null && !loginRegistration.isEmpty() && passwordRegistration != null && !passwordRegistration.isEmpty()) {
                if (!users.containsKey(loginRegistration)) {
                    MNuser newUser = new MNuser(loginRegistration, passwordRegistration, 1); // default privilege level 1
                    users.put(loginRegistration, newUser);
                    application.setAttribute("users", users);
                    session.setAttribute("message1", "User has been saved!");
                } else {
                    session.setAttribute("message1", "User already exists!");
                }
            } else {
                session.setAttribute("message1", "Username and password cannot be empty!");
            }
        }
        else if (action.equals("logout")) {
            session.invalidate();
            // or we can "erase" user:
        }
        if (!action.equals("settings"))
            response.sendRedirect("index.jsp?page=settings");
        else response.sendRedirect("index.jsp");
    }
}