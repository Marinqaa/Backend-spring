package pk.wieik.it.model;

public class MNuser {
    private String login = "";
    private String password;
    private int privileges = -1;
    String name = "";
    String surname = "";
    int age = 0;
    private String backgroundColor;
    public MNuser() {
    }
    public MNuser(String login, String password, int privileges) {
        this.login = login;
        this.password = password;
        this.privileges = privileges;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = filter(name);
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = filter(surname);
    }

    public String getAge(){
        if(age>=0)
            return ""+age;
        else return "";
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getLogin() {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String login) {
        this.password = password;
    }
    public int getPrivileges () {
        return privileges;
    }
    public void setPrivileges (int privileges) {
        this.privileges = privileges;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(String backgroundColor) {
        this.backgroundColor = backgroundColor;
    }
    @Override
    public String toString() {
        return "DGuser{" +
                "login='" + login + '\'' +
                ", privileges=" + privileges +
                '}';
    }

    public String filter(String input) {
        StringBuffer filtered = new StringBuffer();
        char c;
        for (int i = 0; i<input.length(); i++){
            c = input.charAt(i);
            switch (c) {
                case '<':
                    filtered.append("&lt;");
                    break;
                case '>':
                    filtered.append("&gt;");
                    break;
                case '"':
                    filtered.append("&quot;");
                    break;
                case '&':
                    filtered.append("&amp;");
                    break;
                default:
                    filtered.append(c);
            }
        }
        return filtered.toString();
    }

}