qudratic = function(a, b, c) {
    this.A = a;
    this.B = b;
    this.C = c;
    this.DELTA = null;
    this.x1 = null;
    this.x2 = null;
}