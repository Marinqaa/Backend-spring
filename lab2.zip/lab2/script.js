const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ];
function functions() {
    let news1 = document.getElementById("news1");
    let news2 = document.getElementById("news2");
    news1.innerHTML = welcome()+"<br/>"+date()+"<br/>";
    news2.innerHTML = daysToBirthday();
}
window.onload = function () {
    functions();
};
function welcome() {
    let today = new Date();
    let hour = today.getHours();
    if( (hour<18) && (hour>6) ) {
        return 'Good morning, ';
    } else {
        return 'Good evening, ';
    }
}

function date() {
    let today = new Date();
    let day =  today.getDate();
    let month = months[today.getMonth()];
    let year = today.getFullYear();

    return 'today is '+ month + ' ' +  day + ' ' + ' '  + year + '.';
}

function daysToBirthday() {
    return '...';
}
