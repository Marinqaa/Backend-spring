package pk.wieik.it.model;

public class MNuser {
    private String login = "";
    private int privileges = -1;
    private String name = "";
    private String surname = "";
    private int age = 0;
    public MNuser() {
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getLogin() {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }
    public int getPrivileges () {
        return privileges;
    }
    public void setPrivileges (int privileges) {
        this.privileges = privileges;
    }

    @Override
    public String toString() {
        return "DGuser{" +
                "login='" + login + '\'' +
                ", privileges=" + privileges +
                '}';
    }



}