package pk.wieik.it;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.Reader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "suggestions", value = "/suggestions")
public class suggestions extends HttpServlet {

    private static final long serialVersionUID = 1L;

    String[] carsList = { "ALFA ROMEO", "AUDI", "BMW", "CHRYSLER", "CITROEN", "DAIHATSU", "FIAT",
            "MERCEDES", "FORD", "HONDA", "ISUZU", "JAGUAR", "LADA", "LANCIA", "MAZDA", "MERCEDES", "MITSUBISHI",
            "NISSAN", "OPEL", "PEUGEOT", "PORSCHE", "RENAULT", "ROVER", "SAAB", "SEAT", "SKODA", "SUBARU",
            "SUZUKI", "TOYOTA", "VOLVO", "VW" };


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        Reader input = new InputStreamReader(request.getInputStream());
        JSONObject json;
        JSONParser jsonParser = new JSONParser();

        try {
            json = (JSONObject) jsonParser.parse(input);
        } catch (ParseException e) {
            json = new JSONObject();
        }

        String query = ((String) json.get("value")).toLowerCase();
        PrintWriter out = response.getWriter();
        ArrayList<String> suggestion = new ArrayList<>();
        try {
            for (String car : carsList) {
                if (car.toLowerCase().startsWith(query)) { // Ignore case while checking for suggestions
                    suggestion.add(car);
                }
            }
            json.put("suggestion", suggestion);
        } finally {
            out.println(json.toJSONString());
            out.close();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}