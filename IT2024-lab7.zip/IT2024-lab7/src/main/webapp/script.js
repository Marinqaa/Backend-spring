function sendAsynchronously(url, method, dataType, uploadedDocument) {
    // Check if window has XMLHttpRequest
    if (!window.XMLHttpRequest)
        return null;

    // Create an XMLHttpRequest object
    let requester = new XMLHttpRequest();

    // Determine the method and type of data to be sent
    method = method || 'GET';
    dataType = dataType || 'text/plain';

    // Send a specific method to a specific URL
    requester.open(method, url);

    // Set the Content-Type header
    requester.setRequestHeader('Content-Type', dataType);

    // handle the readyState change event
    requester.onreadystatechange = function() {
        let el = document.getElementById("results");
        el.style.display = 'block';
        el.innerHTML = 'Loading data...';
        // check the readyState property
        if (requester.readyState == 4) { // 4 means DONE
            // check the status (optimistically it should be 200)
            if (requester.status == 200) {
                let responseText = requester.responseText;
                let response = JSON.parse(responseText);
                let results = "";
                for (let value of response.suggestion) {
                    results += '<div class="list">' + value + '</div>';
                }
                el.innerHTML = results;
            } else { // handle a possible error
                console.log("status error " + requester.status);
            }
        }
    }

    // Send a request
    requester.send(uploadedDocument);
    return requester;
}

function getSuggestions() {
    let input = document.getElementById("field").value.trim();
    if(input === ""){
        document.getElementById("results").innerHTML = "";
        return;
    }
    let value = {"value": input};
    sendAsynchronously("suggestions", "POST", "application/json", JSON.stringify(value));
}

function getSuggestionsjQuery() {
    let input = $('#field2').val().toLowerCase(); // Convert input to lowercase
    if(input === ""){
        $("#results2").empty(); // Clear suggestion div if input is empty
        return;
    }

    let parameters = {"value": input};

    $("#results2").css("display", "block").html("Loading data...");

    $.ajax({
        url: 'suggestions',
        type: 'POST',
        dataType: 'json',
        data: JSON.stringify(parameters),
        contentType: 'application/json',
        success: function(data) {
            $("#results2").html("");
            $.each(data.suggestion, function(index, result) {
                $("#results2").append('<div class="list">' + result + '</div>');
            });
        },
        error: function(response) {
            console.log("status: " + response.status);
            $("#results2").html("Error receiving data!");
        }
    });
}

// Event listener for suggestions in jQuery results
$(document).on("click", "#results2 .list", function(e) {
    e.stopPropagation(); // Stop event propagation to prevent it from reaching the parent elements
    let selectedValue = $(this).text();
    $('#field2').val(selectedValue);
    $("#results2").empty(); // Clear suggestion div
});

// Event listener for suggestions in AJAX results
$(document).on("click", "#results .list", function(e) {
    e.stopPropagation(); // Stop event propagation to prevent it from reaching the parent elements
    let selectedValue = $(this).text();
    $('#field').val(selectedValue);
    $("#results").empty(); // Clear suggestion div
});