function sendAsynchronously(url, method, dataType, data) {
    if (!window.XMLHttpRequest) return null;

    const requester = new XMLHttpRequest();

    requester.open(method || "GET", url);
    requester.setRequestHeader("Content-Type", dataType || "text/plain");

    requester.onreadystatechange = function() {
        const el = document.getElementById("results");
        el.style.display = "block";
        el.innerHTML = "Loading data...";

        if (requester.readyState === 4) {
            if (requester.status === 200) {
                let response= requester.responseText.split(";");
                let results = '';
                response.forEach(value=>{
                    results += '<div class="list>'+value+'</div>'
                });
                el.innerHTML = results;
            }else {
                console.log("status error " + requester.status);
            }
        }
    }


    requester.send(data);

    return requester;
}

function getSuggestions() {
    const value = { value: document.getElementById("field").value };
    sendAsynchronously("suggestionsBackend", "POST", "application/json", JSON.stringify(value));
}