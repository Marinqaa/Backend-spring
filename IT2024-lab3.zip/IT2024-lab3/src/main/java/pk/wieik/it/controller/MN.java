package pk.wieik.it.controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import pk.wieik.it.model.Tools;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

@WebServlet(name = "MN", value = "/MN")
public class MN extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        ServletContext context = getServletContext();
        PrintWriter out = response.getWriter();

        String page = request.getParameter("page");
        page = Tools.parsePage(page, "main;quadratic;third");

        if (page.equals("quadratic")) {
            String[] jsFiles = {"quadratic.js"};
            String onloadFunction = "hook();";
            String additionalScripts = Tools.includeJavaScript(jsFiles, onloadFunction);
            request.setAttribute("additionalScripts", additionalScripts);
        }

        String template = Tools.getTemplate("index.html", context);

        template = Tools.fill(template, "HEADER", "header.html", context);
        template = Tools.fill(template, "MENU", "menu.html", context);
        template = Tools.fill(template, "CONTENT", page + ".html", context);
        template = Tools.fill(template, "FOOTER", "footer.html", context);


        out.println(template);
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}